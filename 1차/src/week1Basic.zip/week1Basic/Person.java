package week1Basic;

public interface Person {
    void speak();
}
